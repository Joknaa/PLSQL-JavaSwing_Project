create FUNCTION f_GetMaxClient RETURN NUMBER IS
    v_MaxClientID NUMBER;
BEGIN
    SELECT ClientID INTO v_MaxClientID FROM (
        SELECT ClientID, SUM(command.totalTTC) AS TotalAmount FROM command GROUP BY ClientID ORDER BY TotalAmount DESC
        ) WHERE ROWNUM <= 1;
    RETURN v_MaxClientID;
END f_GetMaxClient;
/

